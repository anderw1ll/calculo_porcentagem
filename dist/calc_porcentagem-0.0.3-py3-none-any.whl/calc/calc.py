def aumento(valor, porcentagem):
    r = valor + (valor * (porcentagem / 100))
    return r

def reducao(valor, porcentagem):
    r = valor - (valor * (porcentagem / 100))
    return r
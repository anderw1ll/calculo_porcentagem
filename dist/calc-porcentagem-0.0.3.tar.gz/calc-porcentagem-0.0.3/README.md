# calc_porcentagem

Descrição.
O pacote calc_porcentagem é usado para:
    Calculos:
        - Aumento de valor baseado na porcentagem informado na chamada da função
        - Diminuição de valor baseado na porcentagem informado na chamada da função

## Instalação

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/estable/) para instalar calc_porcentagem

```bash
pip install -i https://test.pypi.org/simple/ calc-porcentagem
```

## Uso

```python
import calc-porcentagem.calc as cp

cp.aumento() #exemplo da chamada de função aumento()
```

## Autor
Anderson Willian

## Licensa
[MIT](https://choosealicense.com/license/mit/)